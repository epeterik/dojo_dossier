export const TITLE_VALUE_UPDATE = "title-value-update";
export const ITEM_VALUE_UPDATE = "item-value-update";
export const ADD_NEW_TITLE = "add-new-title";
export const ADD_NEW_ITEM = "add-new-item";
export const SELECTED_DOSSIER = "selected-dossier"
